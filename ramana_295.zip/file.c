#include <stdio.h>
#include "file.h"
#include "contact.h"

void saveContactsToFile(AddressBook *addressBook) {
  
}


void loadContactsFromFile(AddressBook *addressBook) {
    
}
